"""Frame-rate independent shortest-path quaternion damping."""
import math

class RotationDamping:
    def __init__(self):
        self.reset()

    def reset(self):
        self.rotation = None
        self.updated_at = None

    def step(self, target, now, response):
        target = target.normalized()
        if self.rotation is None or response <= 0:
            self.rotation = target.copy()
        else:
            if self.rotation.dot(target) < 0:
                target.negate()
            dt = max(0.0, now - self.updated_at)
            alpha = -math.expm1(-dt / response)
            self.rotation = self.rotation.slerp(target, alpha).normalized()
        self.updated_at = now
        return self.rotation.copy()
