"""Camera preview: vectorized GPU readback, latest-only background PNG encoding."""
import base64, struct, time, zlib, threading
import bpy
import gpu
import numpy as np

class CameraPreview:
    def __init__(self, runtime):
        self.runtime=runtime;self.offscreen=None;self.last=0;self.error='等待相机画面'
        self.pending=None;self.lock=threading.Lock();self.event=threading.Event();self.closed=False
        self.frames=0;self.render_ms=0;self.encode_ms=0;self.drawing=False
        self.worker=threading.Thread(target=self.encode,daemon=True);self.worker.start()
        self.handler=bpy.types.SpaceView3D.draw_handler_add(self.draw,(), 'WINDOW','POST_PIXEL')

    def encode(self):
        while not self.closed:
            self.event.wait(.5);self.event.clear()
            with self.lock:item,self.pending=self.pending,None
            if item is None:continue
            width,height,raw,state=item;t=time.monotonic()
            stride=width*4
            scan=b''.join(b'\0'+raw[y*stride:(y+1)*stride] for y in range(height-1,-1,-1))
            def chunk(kind,data):return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data)&0xffffffff)
            png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',width,height,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(scan,1))+chunk(b'IEND',b'')
            self.encode_ms=(time.monotonic()-t)*1000
            if not self.closed:self.runtime.rx.publish(dict(state,image=base64.b64encode(png).decode('ascii')))

    def draw(self):
        if self.drawing:return
        r=self.runtime;now=time.monotonic()
        if now-self.last<1/20 or not r.rx.snapshot()[2]:return
        if bpy.context.scene!=r.scene:return
        self.last=now;self.drawing=True
        try:
            width=640;height=max(32,min(640,round(width*r.scene.render.resolution_y*r.scene.render.pixel_aspect_y/(r.scene.render.resolution_x*r.scene.render.pixel_aspect_x))))
            if self.offscreen is None or self.offscreen.width!=width or self.offscreen.height!=height:
                if self.offscreen:self.offscreen.free()
                self.offscreen=gpu.types.GPUOffScreen(width,height)
            deps=bpy.context.evaluated_depsgraph_get();camera=r.obj.evaluated_get(deps)
            projection=camera.calc_matrix_camera(deps,x=width,y=height,scale_x=r.scene.render.pixel_aspect_x,scale_y=r.scene.render.pixel_aspect_y)
            space=bpy.context.space_data
            self.offscreen.draw_view3d(r.scene,bpy.context.view_layer,space,bpy.context.region,camera.matrix_world.inverted(),projection,do_color_management=True)
            with self.offscreen.bind():
                buf=gpu.state.active_framebuffer_get().read_color(0,0,width,height,4,0,'UBYTE')
                buf.dimensions=width*height*4
                raw=np.asarray(buf,dtype=np.uint8).tobytes()
            self.error='';self.frames+=1;self.render_ms=(time.monotonic()-now)*1000
            with self.lock:self.pending=(width,height,raw,r.phone_state())
            self.event.set()
        except Exception as exc:self.error='预览不可用: '+str(exc)[:90]
        finally:self.drawing=False

    def close(self):
        self.closed=True;self.event.set()
        bpy.types.SpaceView3D.draw_handler_remove(self.handler,'WINDOW')
        if self.offscreen:self.offscreen.free()
