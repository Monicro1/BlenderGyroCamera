bl_info = {'name':'手机陀螺仪相机', 'author':'Gyro Camera', 'version':(1,2,1), 'blender':(3,6,0), 'location':'3D 视图 > N 面板 > 手机相机', 'description':'通过 Wi-Fi 或 USB 实时控制相机并录制 XYZ 旋转关键帧', 'category':'Animation'}
import bpy
import math
import random
import socket
import time
from mathutils import Quaternion
from bpy.app.handlers import persistent
from .receiver import Receiver
from .usb_auto import AutoUSB
from .damping import RotationDamping
from .preview import CameraPreview

def orientation_basis(grip):
    # Camera local coordinates: right X, up Y, toward viewer Z.
    # For a phone with earpiece on left: device +Y points screen-left.
    return Quaternion((0,0,1), {'LEFT':math.pi/2,'RIGHT':-math.pi/2,'PORTRAIT':0}[grip])

_runtime = None

def playing():
    return any(w.screen and w.screen.is_animation_playing for w in bpy.context.window_manager.windows)

def set_playback(active):
    if active and not playing():bpy.ops.screen.animation_play()
    elif not active and playing():bpy.ops.screen.animation_cancel(restore_frame=False)

def camera_poll(self, obj):
    return obj.type == 'CAMERA'

class GyroSettings(bpy.types.PropertyGroup):
    camera: bpy.props.PointerProperty(name='目标相机', type=bpy.types.Object, poll=camera_poll)
    port: bpy.props.IntProperty(name='监听端口', default=8765, min=1024, max=65535)
    token: bpy.props.StringProperty(name='配对码', default='', maxlen=32)
    grip: bpy.props.EnumProperty(name='握持方式', items=[('LEFT','横屏 · 听筒在左',''),('RIGHT','横屏 · 听筒在右',''),('PORTRAIT','竖屏','')], default='LEFT')
    damping: bpy.props.FloatProperty(name='旋转阻尼（秒）', description='平滑响应时间；0 为关闭，越大越平稳但跟随越慢', default=0.12, min=0.0, max=0.5, precision=2, step=1)
    auto_usb: bpy.props.BoolProperty(name='自动 USB（插线授权即连接）', default=True)

class Runtime:
    def __init__(self, scene, obj, settings):
        self.scene = scene
        self.obj = obj
        self.rx = Receiver(settings.port, settings.token)
        self.usb = AutoUSB(settings.port, settings.token) if settings.auto_usb else None
        self.grip = settings.grip
        self.recording = False
        self.reference = None
        self.base = obj.rotation_euler.to_quaternion() if obj.rotation_mode not in {'QUATERNION','AXIS_ANGLE'} else obj.matrix_basis.to_quaternion()
        self.zero_id = -1
        self.last_frame = None
        self.last_euler = obj.matrix_basis.to_euler('XYZ')
        self.note = '等待手机连接'
        self.damping = RotationDamping()
        self.busy = False
        self.remote_playback = False
        self.last_status = 0
        self.preview = CameraPreview(self) if not bpy.app.background else None

    def phone_state(self):
        return {'type':'state','recording':self.recording,'playing':playing(),'frame':self.scene.frame_current,'message':self.note,'preview_error':self.preview.error if self.preview else '无可用 3D 视口'}

    def stop_phone_record(self):
        self.recording = False
        if self.remote_playback and playing():
            set_playback(False)
        self.remote_playback = False

    def phone_commands(self):
        for command in self.rx.take_commands():
            if command == 'record_stop':
                self.stop_phone_record();self.note='手机已停止录制与播放'
            elif not self.recording:
                pose, _, connected, _, _ = self.rx.snapshot()
                if not connected or not pose or time.monotonic()-pose[1]>=1:
                    self.note='无法录制：请先连接并发送姿态';continue
                if not playing():
                    try:set_playback(True)
                    except RuntimeError:
                        self.note='无法启动时间线播放';continue
                if not playing():
                    self.note='无法启动时间线播放';continue
                self.remote_playback=True;self.recording=True;self.last_frame=None
                self.note='手机录制中';self.apply(record=True)
        if self.remote_playback and not self.recording:self.stop_phone_record()
        now=time.monotonic()
        if now-self.last_status>.5:
            self.rx.publish(self.phone_state());self.last_status=now

    def zero(self):
        self.damping.reset()
        self.reference = None
        self.base = self.obj.matrix_basis.to_quaternion()
        self.last_euler = self.obj.matrix_basis.to_euler('XYZ')

    def apply(self, record=False):
        if self.busy:
            return
        pose, zid, connected, peer, error = self.rx.snapshot()
        fresh = pose is not None and time.monotonic()-pose[1] < 1.0
        if not connected or not fresh:
            self.damping.reset()
            if self.recording:
                self.recording = False
                self.note = '手机断开或数据超时，录制已停止'
            return
        if self.obj.name not in self.scene.objects:
            self.recording = False
            self.note = '目标相机已移出场景'
            return
        q = Quaternion(pose[0])
        if zid != self.zero_id:
            self.zero_id = zid
            self.zero()
        if self.reference is None:
            self.reference = q.copy()
        basis = orientation_basis(self.grip)
        delta = basis @ (self.reference.inverted() @ q) @ basis.inverted()
        target = self.base @ delta
        smooth = self.damping.step(target, time.monotonic(), self.scene.gyro_camera.damping)
        rotation = smooth.to_euler('XYZ', self.last_euler)
        self.busy = True
        try:
            self.obj.rotation_mode = 'XYZ'
            self.obj.rotation_euler = rotation
            self.last_euler = rotation.copy()
            if record and self.recording and self.scene.frame_current != self.last_frame:
                self.obj.keyframe_insert(data_path='rotation_euler', frame=self.scene.frame_current, group='手机陀螺仪 XYZ')
                self.last_frame = self.scene.frame_current
                self.note = '已记录帧 %d' % self.last_frame
        finally:
            self.busy = False

def stop_runtime():
    global _runtime
    if _runtime:
        _runtime.stop_phone_record()
        if _runtime.preview:_runtime.preview.close()
        if _runtime.usb:_runtime.usb.close()
        _runtime.rx.close()
        _runtime = None

def tick():
    if _runtime:
        try:
            _runtime.phone_commands()
            if not playing():
                if _runtime.recording:
                    _runtime.recording = False
                    _runtime.note = '播放已停止，录制已停止'
                _runtime.apply()
            else:
                # Also detect a disconnected sender when playback is stalled.
                pose, _, connected, _, _ = _runtime.rx.snapshot()
                if not connected or pose is None or time.monotonic()-pose[1] >= 1:
                    _runtime.recording = False
        except (ReferenceError, RuntimeError) as exc:
            globals()['_last_error'] = str(exc)
            stop_runtime()
            print('Gyro camera stopped:', exc)
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':area.tag_redraw()
    return 1/60

@persistent
def frame_changed(scene, depsgraph=None):
    if _runtime and scene == _runtime.scene and playing():
        _runtime.apply(record=True)

@persistent
def before_load(_):
    stop_runtime()

class GYRO_OT_listen(bpy.types.Operator):
    bl_idname = 'gyro.listen'
    bl_label = '开始 / 停止监听'
    def execute(self, context):
        global _runtime
        if _runtime:
            stop_runtime()
            return {'FINISHED'}
        s = context.scene.gyro_camera
        obj = s.camera or context.scene.camera
        if not obj:
            self.report({'ERROR'}, '请先选择目标相机')
            return {'CANCELLED'}
        if obj.constraints or obj.animation_data and obj.animation_data.drivers:
            self.report({'ERROR'}, '请使用没有约束和驱动器的相机；可新建相机避免旋转被覆盖')
            return {'CANCELLED'}
        if not s.token:
            s.token = str(random.SystemRandom().randint(100000,999999))
        try:
            _runtime = Runtime(context.scene, obj, s)
        except OSError as exc:
            self.report({'ERROR'}, '监听失败：%s' % exc)
            return {'CANCELLED'}
        return {'FINISHED'}

class GYRO_OT_zero(bpy.types.Operator):
    bl_idname = 'gyro.zero'
    bl_label = '以当前姿态归零'
    def execute(self, context):
        if _runtime:_runtime.zero()
        return {'FINISHED'}

class GYRO_OT_record(bpy.types.Operator):
    bl_idname = 'gyro.record'
    bl_label = '开始 / 停止录制关键帧'
    def execute(self, context):
        if not _runtime:return {'CANCELLED'}
        if _runtime.recording:
            _runtime.recording = False
            _runtime.note = '录制已停止'
            return {'FINISHED'}
        pose, _, connected, _, _ = _runtime.rx.snapshot()
        if not playing() or not connected or not pose or time.monotonic()-pose[1] >= 1:
            self.report({'ERROR'}, '请连接手机并先播放动画')
            return {'CANCELLED'}
        _runtime.recording = True
        _runtime.last_frame = None
        _runtime.note = '正在录制；停止播放或断开会结束录制'
        _runtime.apply(record=True)
        return {'FINISHED'}

class GYRO_PT_panel(bpy.types.Panel):
    bl_label = '手机陀螺仪相机'
    bl_idname = 'GYRO_PT_camera'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '手机相机'
    def draw(self, context):
        layout = self.layout
        s = context.scene.gyro_camera
        col = layout.column()
        col.enabled = _runtime is None
        col.prop(s,'camera')
        col.prop(s,'port')
        col.prop(s,'token')
        col.prop(s,'grip')
        col.prop(s,'auto_usb')
        layout.prop(s,'damping')
        layout.operator('gyro.listen',text='停止监听' if _runtime else '开始监听')
        if _runtime:
            box=layout.box()
            if _runtime.usb:box.label(text=_runtime.usb.status)
            try:
                ips = sorted(set(i[4][0] for i in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET)))
            except OSError:ips=[]
            for ip in ips:box.label(text='电脑 IP: '+ip)
            if not ips:box.label(text='电脑 IP：请用 ipconfig 查询')
            pose, _, connected, peer, error = _runtime.rx.snapshot()
            box.label(text=('已连接: '+peer) if connected else '等待手机连接')
            if error and not connected:box.label(text=error[:55],icon='ERROR')
            layout.operator('gyro.zero')
            row = layout.row()
            row.alert = _runtime.recording
            row.operator('gyro.record',text='停止录制关键帧' if _runtime.recording else '开始录制关键帧', icon='REC')
            layout.label(text=_runtime.note)
        layout.label(text='先播放动画，再点击录制')
        layout.label(text='录制覆盖经过帧的 XYZ 旋转')

classes=(GyroSettings,GYRO_OT_listen,GYRO_OT_zero,GYRO_OT_record,GYRO_PT_panel)
def register():
    for cls in classes:bpy.utils.register_class(cls)
    bpy.types.Scene.gyro_camera=bpy.props.PointerProperty(type=GyroSettings)
    bpy.app.handlers.frame_change_post.append(frame_changed)
    bpy.app.handlers.load_pre.append(before_load)
    bpy.app.timers.register(tick,persistent=True)

def unregister():
    stop_runtime()
    if bpy.app.timers.is_registered(tick):bpy.app.timers.unregister(tick)
    if frame_changed in bpy.app.handlers.frame_change_post:bpy.app.handlers.frame_change_post.remove(frame_changed)
    if before_load in bpy.app.handlers.load_pre:bpy.app.handlers.load_pre.remove(before_load)
    del bpy.types.Scene.gyro_camera
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
