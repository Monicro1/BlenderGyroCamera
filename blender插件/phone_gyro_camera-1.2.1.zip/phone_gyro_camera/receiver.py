"""Bounded JSON-lines TCP receiver. No Blender API on network threads."""
import json
import math
import socket
import threading
import time
from collections import deque

MAX_LINE = 2048

class Receiver:
    def __init__(self, port, token):
        self.token = token
        self.lock = threading.Lock()
        self.latest = None
        self.zero_id = 0
        self.connected = False
        self.peer = ''
        self.error = ''
        self.closed = threading.Event()
        self.client = None
        self.commands = deque(maxlen=16)
        self.outgoing = None
        self.send_event = threading.Event()
        self.send_thread = threading.Thread(target=self._send_loop, daemon=True)
        self.send_thread.start()
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(('0.0.0.0', port))
        self.sock.listen(2)
        self.sock.settimeout(0.5)
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def snapshot(self):
        with self.lock:
            return self.latest, self.zero_id, self.connected, self.peer, self.error

    def take_commands(self):
        with self.lock:
            result = list(self.commands)
            self.commands.clear()
            return result

    def publish(self, data):
        with self.lock:
            self.outgoing = data
        self.send_event.set()

    def _send_loop(self):
        while not self.closed.is_set():
            self.send_event.wait(.5)
            self.send_event.clear()
            with self.lock:
                data, self.outgoing = self.outgoing, None
                conn = self.client if self.connected else None
            if conn and data:
                try:self._send(conn, data)
                except OSError:pass

    def _send(self, conn, data):
        conn.sendall((json.dumps(data) + '\n').encode('utf-8'))

    def _run(self):
        while not self.closed.is_set():
            try:
                conn, addr = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            self.client = conn
            try:
                conn.settimeout(2)
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                pending = b''
                authenticated = False
                last = time.monotonic()
                while not self.closed.is_set():
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    pending += chunk
                    if len(pending) > MAX_LINE and b'\n' not in pending:
                        raise ValueError('message too long')
                    while b'\n' in pending:
                        line, pending = pending.split(b'\n', 1)
                        if len(line) > MAX_LINE:
                            raise ValueError('message too long')
                        msg = json.loads(line)
                        if not authenticated:
                            if msg.get('type') != 'hello' or msg.get('version') != 1 or msg.get('token') != self.token:
                                self._send(conn, {'type':'error','message':'配对码或协议不匹配'})
                                raise ValueError('authentication failed')
                            authenticated = True
                            self._send(conn, {'type':'welcome','version':1})
                            with self.lock:
                                self.connected = True
                                self.peer = addr[0]
                                self.latest = None
                                self.zero_id += 1
                        elif msg.get('type') == 'pose':
                            q = msg.get('q')
                            if not isinstance(q, list) or len(q) != 4 or any(isinstance(x, bool) or not isinstance(x, (float, int)) or not math.isfinite(x) for x in q):
                                raise ValueError('invalid quaternion')
                            norm = math.sqrt(sum(x*x for x in q))
                            if norm < 0.5 or norm > 1.5:
                                raise ValueError('invalid quaternion norm')
                            with self.lock:
                                self.latest = (tuple(x/norm for x in q), time.monotonic())
                        elif msg.get('type') in {'record_start','record_stop'}:
                            with self.lock:self.commands.append(msg['type'])
                        elif msg.get('type') == 'zero':
                            with self.lock:
                                self.zero_id += 1
                        last = time.monotonic()
                    if time.monotonic()-last > 3:
                        break
            except (OSError, ValueError, TypeError, AttributeError, UnicodeError) as exc:
                if not self.closed.is_set():
                    self.error = str(exc)
            finally:
                conn.close()
                self.client = None
                with self.lock:
                    self.connected = False
                    self.latest = None
                    self.commands.clear()
                    self.outgoing = None

    def close(self):
        self.closed.set()
        if self.client:
            try:self.client.shutdown(socket.SHUT_RDWR)
            except OSError:pass
        self.sock.close()
        self.thread.join(timeout=3)
