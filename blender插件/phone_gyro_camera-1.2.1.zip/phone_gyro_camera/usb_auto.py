"""Windows automatic ADB lifecycle. Never call bpy from this worker."""
import pathlib
import subprocess
import threading

class AutoUSB:
    def __init__(self, port, token):
        self.port = port
        self.token = token
        self.status = '正在检测 USB 手机'
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def command(self, *args):
        adb = pathlib.Path(__file__).parent/'usb'/'adb.exe'
        return subprocess.run([str(adb), *args], capture_output=True, text=True,
                              encoding='utf-8', errors='replace', timeout=8,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))

    def run(self):
        ready = None
        while not self.stop_event.is_set():
            try:
                r = self.command('devices')
                lines = [s.split() for s in r.stdout.splitlines()[1:] if s.strip()]
                devices = [s[0] for s in lines if len(s)>1 and s[1]=='device' and ':' not in s[0] and not s[0].startswith('emulator-')]
                if len(devices)>1:
                    self.status='检测到多台手机，请只保留一台 USB 设备';ready=None
                elif not devices:
                    self.status='请在手机允许 USB 调试' if any(len(s)>1 and s[1]=='unauthorized' for s in lines) else '等待插入 USB 手机'
                    ready=None
                else:
                    serial=devices[0]
                    listing=self.command('-s',serial,'reverse','--list')
                    expected='tcp:%d tcp:%d'%(self.port,self.port)
                    if expected not in listing.stdout:
                        r=self.command('-s',serial,'reverse','tcp:%d'%self.port,'tcp:%d'%self.port)
                        if r.returncode:raise RuntimeError(r.stderr.strip())
                        ready=None
                    if ready!=serial:
                        # Explicit exported Activity, local USB authorization is required.
                        r=self.command('-s',serial,'shell','am','start','-n','cn.gyrocamera.phone/.MainActivity',
                            '--ez','usb_auto','true','--ei','port',str(self.port),'--es','token',self.token)
                        if r.returncode or 'Error' in r.stdout or 'Error' in r.stderr:
                            raise RuntimeError('请先安装新版手机 APK')
                        ready=serial
                    self.status='USB 已就绪 · 自动恢复已开启'
            except FileNotFoundError:self.status='缺少内置 ADB，请重新安装完整插件包'
            except (OSError,subprocess.SubprocessError,RuntimeError) as exc:self.status='USB: '+str(exc)[:85]
            self.stop_event.wait(2)

    def close(self):
        self.stop_event.set()
        # Worker never touches Blender state, so do not freeze UI awaiting ADB.
